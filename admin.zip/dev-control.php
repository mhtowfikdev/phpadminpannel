<?php

require_once( __DIR__ . '/constants.php' );

/* ============================================ */

$APP_AVAILABLE = true;
$DEV_MESSAGE = "App Unavailable";

error_reporting(0);

/* ============================================ */