<section class="footer">
          <a href="https://t.me/osappdeveloperbd" style="color: #ffffff; text-decoration: none">Developed By OS Developer BD</a>
</section>