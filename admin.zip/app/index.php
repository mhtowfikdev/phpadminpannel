<?php 
require_once('./includes/init.php');
$data = file_get_contents($data_file);
$dd = json_decode($data);

if($dd->app_theme == "Modern"){
    include 'home-design-one.php'; 
}
if($dd->app_theme == "Modern_Pro"){
    include 'home-design-six.php'; 
}
if($dd->app_theme == "Classic"){
  include 'home-design-two.php';
}
if($dd->app_theme == "Classic_Pro"){
  include 'home-design-five.php';
}
if($dd->app_theme == "Elegant"){
  include 'home-design-three.php';
}
if($dd->app_theme == "Elegant_Pro"){
  include 'home-design-four.php';
}

?>